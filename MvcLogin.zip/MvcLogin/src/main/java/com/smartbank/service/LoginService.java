package com.smartbank.service;


import com.smartbank.model.*;

public interface LoginService{    
       public boolean checkLogin(String userName, String userPassword);
}