package com.smartbank.controllers;

import java.util.Map;


import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.smartbank.form.AccountCreation;


@Controller
@RequestMapping("/accountcreationform.html")
public class AccountCreationController {
	@Autowired
	private AccountCreationValidation accountcreationValidation;

	public void setAccountCreationValidation(
			AccountCreationValidation accountcreationValidation) {
		this.accountcreationValidation = accountcreationValidation;
	}

	
	@RequestMapping(method = RequestMethod.GET)
	public String showAccountCreation(Map model) {
		 AccountCreation accountcreation = new AccountCreation();
		model.put("accountcreation", accountcreation);
		return "accountcreationform";
	}

	
	@RequestMapping(method = RequestMethod.POST)
	public String processAccountCreation(@Valid AccountCreation accountcreation,
			BindingResult result) {
		
		accountcreationValidation.validate(accountcreation, result);
		if (result.hasErrors()) {
			return "accountcreationform";
		}
		return "accountcreationsuccess";
	}
}
