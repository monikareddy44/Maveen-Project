package com.smartbank.controllers;

import org.springframework.stereotype.Component;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;

import com.smartbank.form.AccountCreation;

@Component("accountcreationValidator")
public class AccountCreationValidation {
	public boolean supports(Class<?> clas) {
		return AccountCreation.class.isAssignableFrom(clas);
	}

	public void validate(Object target, Errors errors) {
		AccountCreation accountcreation = (AccountCreation) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstName",
				"NotEmpty.accountcreation.firstName",
				"User Name must not be Empty.");
		String firstName = accountcreation.getFirstName();
		if ((firstName.length()) > 50) {
			errors.rejectValue("firstName",
					"lengthOfUser.accountcreation.firstName",
					"User Name must not more than 50 characters.");
		}
		
	}
}
